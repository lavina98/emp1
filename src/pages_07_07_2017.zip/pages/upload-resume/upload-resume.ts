  import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, LoadingController} from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';
import { FileChooser, } from '@ionic-native/file-chooser';
import { FilePath } from '@ionic-native/file-path'
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer'
import { Storage } from '@ionic/storage';
import { LoginPage } from '../login/login';
import { ResumeBuilderPage } from '../resume-builder/resume-builder';
import { Toast } from '@ionic-native/toast'
@Component({
  selector: 'page-upload-resume',
  templateUrl: 'upload-resume.html'
})
export class UploadResumePage {
  resume:any
  options:any;
  completed:any;
  hash:any
  empid:any
  uploaded:number;
  http:any;
  todo:any;
  we:any;
  bd:any;
  pname:any;
  city:any;
  c_id:any;
  experience:any;
  picture:any;
  name:any;
  email:any
  gender:any
  number:any
  password:any;
  view_resume:any
  view_picture:any
  qualification:any
  skills:any;
  org:any;
  catering:any;
  internship:any
  referrer: any
  constructor(public transfer: FileTransfer,private fp: FilePath ,private fc:FileChooser,public storage: Storage,http: Http,public navCtrl: NavController, public navParams: NavParams,public alertCtrl: AlertController, public loadingCtrl: LoadingController) {
    this.name = navParams.get('name')
    this.email = navParams.get('email')
    this.gender = navParams.get('gender')
    this.number = navParams.get('number') 
    this.picture = navParams.get('picture')
    this.referrer = navParams.get('referrer')
    this.password = navParams.get('password')
    if(this.password == ''){
       this.password = 'SOCIAL_LOGIN_PASSWORD';
     }
    this.we = navParams.get('we')
    this.experience = navParams.get('experience')
    this.qualification = navParams.get('qualification')
    this.skills = navParams.get('skills')
    this.org = navParams.get('org')
    if(this.org == ''){
      this.org= "None"
    }
    this.catering = navParams.get('catering')
    this.internship = navParams.get('internship')
    this.pname = navParams.get('pname')
    this.city = navParams.get('city')
    this.c_id = navParams.get('c_id')
    this.http = http;
      this.storage.get('Hash').then((hash) => {
        this.hash = hash;
      });
      this.uploaded = 0;
  }

    buildResume(){
      this.navCtrl.push(ResumeBuilderPage, {
              experience: this.experience,
              qualification:this.qualification,
              skills: this.skills,
              org:this.org,
              catering:this.catering,
              internship: this.internship,
              we:this.we,
              referrer: this.referrer,
              name: this.name,
              email:this.email,
              number:this.number,
              gender:this.gender,
              password:this.password,
              pname: this.pname,
              city: this.city,
              c_id: this.c_id,
              picture: this.picture
            });
        }
        
      clickRegister(){
      if(this.resume == null){
      let alert = this.alertCtrl.create({
                title: 'Error!',
                subTitle: 'Kindly upload your Resume to Register',
                buttons: ['OK']
                });
                alert.present();
    }
    if(this.picture == null){
      let alert = this.alertCtrl.create({
                title: 'Error!',
                subTitle: 'Kindly upload your Profile Picture to Register',
                buttons: ['OK']
                });
                alert.present();
    }
     if((this.picture != null) && (this.resume != null)){
       let loading = this.loadingCtrl.create({
        spinner: 'dots',
        content: 'Creating your account...'
      });
      loading.present();
    let body = JSON.stringify({
        name: this.name,
        password: this.password,
        contact_no: this.number,
        user_type: 2,
        region: 'India',
        email: this.email,
        gender: this.gender,
        profile_pic: this.picture,
        experience: this.experience,
        designation: this.pname,
        qualification: this.qualification,
        org: this.org,
        internship: this.internship,
        catering: this.catering,
        referrer: this.referrer
      });
      let headers = new Headers({
        'Content-Type': 'application/json',
        'Authorization': this.hash
      });
      let options = new RequestOptions({ headers: headers });
      this.http
          .post('http://forehotels.com:3000/api/users_employee', body, options)
          .subscribe(
              datas => {
                console.log(datas);
                this.empid = JSON.parse(datas._body).User;
                loading.dismiss()

                if(this.picture == null){
                this.pictureUpload(this.picture)
                }
                else{
                  this.uploaded++
                }
                this.resumeUpload(this.resume)
                let city_body = JSON.stringify({
                      city_id:this.c_id,
                      user_id: this.empid
                    });
                    console.log(city_body)
        this.http
          .post('http://forehotels.com:3000/api/users_city', city_body, options)
          .map(res => res.json())
          .subscribe(
              data => {
                console.log(data);
                let email_body = JSON.stringify({
                    email: this.email,
                    mail: 'employee_welcome'
                        });
                    this.http
                    .post('http://forehotels.com:3000/api/send_email', email_body, options)
                    .map(res => res.json())
                    .subscribe(
                        data => {
                          console.log(data)
                    });
                let sms_body = JSON.stringify({
                    number: this.number,
                    text: 'Hello '+this.name+', Welcome to Forehotels. Use the Forehotels App regularly for latest Job openings'
                        });
                    this.http
                    .post('http://forehotels.com:3000/api/send_sms', sms_body, options)
                    .map(res => res.json())
                    .subscribe(
                        data => {
                          console.log(data)
                    });
              },
              err => {
                let alert = this.alertCtrl.create({
                  title: 'Oops!',
                  subTitle: err.text(),
                  buttons: ['OK']
                  });
                  alert.present();
              }
          );
              },
              err => {
                console.log("ERROR!: ", err);
              }
          );
      }
    }
      success(){
      if(this.uploaded == 2){
        let alert = this.alertCtrl.create({
                  title: 'Congrats!',
                  subTitle: 'Your Account Has been Created Successfully.',
                  buttons: ['OK']
                  });
                  alert.present();

        this.navCtrl.setRoot(LoginPage)
      }
    }
    uploadResume(){
    this.fc.open()
      .then(
        uri => {
        this.fp.resolveNativePath(uri)
        .then(filePath => {
          let x = filePath
          var fileArray = x.split("/");
          let len = fileArray.length;
          var file = fileArray[len - 1];
          var filebits = file.split(".");
          var f = filebits[1];
          if((f != "pdf") && (f != "doc") && (f != "docx") && (f!= "rtf")){
            let alert = this.alertCtrl.create({
                  title: "Invalid File Format",
                  subTitle: "Allowed File extensions are PDF, DOC, DOCX and RTF only",
                  buttons: ['Dismiss'],
                });
                alert.present();
          }
          else{
            this.resume = x
            this.view_resume = file
          }
        });
      });
    }
    uploadPicture(){
    this.fc.open()
      .then(
        uri => {
        this.fp.resolveNativePath(uri)
        .then(filePath => {
          let x = filePath
          var fileArray = x.split("/");
          let len = fileArray.length;
          var file = fileArray[len - 1];
          var filebits = file.split(".");
          var f = filebits[1];

          if((f != "jpg") && (f != "png") && (f != "jpeg")){
            let alert = this.alertCtrl.create({
                  title: "Invalid File Format",
                  subTitle: "Allowed File extensions are JPG, JPEG and PNG only",
                  buttons: ['Dismiss'],
                });
                alert.present();
          }
          else{
            this.picture = x
            this.view_picture = file
          }
        });
      });
    }
  resumeUpload(x){
      let loading = this.loadingCtrl.create({
        spinner: 'dots',
        content: 'Uploading your Resume...'
        });
      loading.present();
      var fileArray = x.split("/");
      let len = fileArray.length;
      var file = fileArray[len - 1];
      let fileTransfer: FileTransferObject = this.transfer.create();

      this.options = {
        fileKey: 'resume',
        fileName: x,
        mimeType: "multipart/form-data",
        headers: {
          authorization : this.hash
        },
        params: {
          name: file,
          id: this.empid
        }
      }

      this.completed = false;
      fileTransfer.upload(x, encodeURI("http://forehotels.com:3000/api/upload_employee_resume"), this.options, true)
      .then((data) => {
        this.completed=true;
        this.uploaded++
        this.success();
        loading.dismiss()
      }, (err) => {
        let alert = this.alertCtrl.create({
              title: err.text(),
              subTitle: err.string(),
              buttons: ['Dismiss'],
            });
            alert.present();
      });
    }  
    pictureUpload(x){
      let loading = this.loadingCtrl.create({
        spinner: 'dots',
        content: 'Uploading your Picture...'
        });
      loading.present();
      var fileArray = x.split("/");
      let len = fileArray.length;
      var file = fileArray[len - 1];
      let fileTransfer: FileTransferObject = this.transfer.create();;     

      this.options = {
        fileKey: 'img',
        fileName: x,
        mimeType: "multipart/form-data",
        headers: {
          authorization : this.hash
        },
        params: {
          name: file,
          id: this.empid
        }
      }
      
      this.completed = false;
      fileTransfer.upload(x, encodeURI("http://forehotels.com:3000/api/upload_employee_image"), this.options, true)
      .then((data) => {
        this.completed=true;
        this.uploaded++;
        loading.dismiss()
      }, (err) => {
        let alert = this.alertCtrl.create({
              title: err.text(),
              subTitle: err.json(),
              buttons: ['Dismiss'],
            });
            alert.present();
      });
    }
  }