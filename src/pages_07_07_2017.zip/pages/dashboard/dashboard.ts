import { Component } from '@angular/core';
import { NavController, MenuController, LoadingController, Platform } from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Storage } from '@ionic/storage';
import { InternationalPlacementPage } from '../international-placement/international-placement';
import { SearchJobsPage } from '../search-jobs/search-jobs';
import { UpdateProfilePage } from '../update-profile/update-profile';
import { JobsAppliedPage } from '../jobs-applied/jobs-applied';
import { CateringJobsPage } from '../catering-jobs/catering-jobs';
import { NotificationsPage } from '../notifications/notifications';
import { GoogleAnalytics } from '@ionic-native/google-analytics';
import { HomePage } from '../home/home';

@Component({
  selector: 'page-dashboard',
  templateUrl: 'dashboard.html'
})
export class DashboardPage {
items:any;
http:any;
counts:any;
ccounts:any;
acounts:any;
applied_jobs:any;
catering_jobs:any;
jobs:any;
ids:any;
notif_count:any;
social_pic:boolean;
rootPage:any;

  constructor(private platform:Platform, 
              public menu: MenuController, 
              public navCtrl: NavController, 
              http: Http, 
              public loadingCtrl: LoadingController, 
              private storage: Storage,
              private ga: GoogleAnalytics) {
    let loading = this.loadingCtrl.create({
      spinner: 'dots',
      content: 'Fetching your Account Details...'
    });
    this.social_pic = false
    this.storage.get('Hash').then((hash) => {

    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': hash
    });
    let options = new RequestOptions({ headers: headers });

    this.http = http;
    this.storage.get('id').then((id) => {
      this.platform.ready().then(() => {
          this.ga.trackEvent("Dashboard", "Opened", "New Session Started", id, true)
          this.ga.setAllowIDFACollection(true)
          this.ga.setUserId(id)
          this.ga.trackView("Dashboard")
        });
        let body = JSON.stringify({
        user_id: id,
        });

        this.http.post("http://forehotels.com:3000/api/notifications_count/", body, options)
              .subscribe(data =>{
              let count = data.json(); //Bind data to items object
              this.notif_count = count.count["0"].count;
              },error => {});

        this.http.get("http://forehotels.com:3000/api/employee/"+id, options)
              .subscribe(data =>{
              this.items=JSON.parse(data._body).Users;
               this.storage.set('user', {
                 name: this.items["0"].name,
                 contact_no: this.items["0"].contact_no,
                 email: this.items["0"].email,
                 id: this.items["0"].id,
                 profile_pic: this.items["0"].profile_pic
               });
               let img = this.items["0"].profile_pic.split("/")
               if(img.length > 1){
                  this.social_pic = true;
               }
               loading.dismiss(); //Bind data to items object
              },error => {});

        this.http.get("http://forehotels.com:3000/api/applied_jobscount/"+id, options)
              .subscribe(data =>{
              this.acounts = data.json(); //Bind data to items object
              this.applied_jobs = this.acounts.Applied_Jobs["0"].count;
              },error => {});

        this.http.get("http://forehotels.com:3000/api/jobscount", options)
              .subscribe(data =>{
              this.counts = data.json(); //Bind data to items object
              this.jobs = this.counts.Jobs["0"].count;
              },error => {});

         this.http.get("http://forehotels.com:3000/api/catering_jobscount", options)
              .subscribe(data =>{
              this.ccounts = data.json(); //Bind data to items object
              this.catering_jobs = this.ccounts.Catering_Jobs["0"].count;
              },error => {});
          });
        });
    }

    Openmenu(){
     this.menu.open();
    }
    internationalplacement(){
      this.navCtrl.push(InternationalPlacementPage);
    }
    notifications(){
      this.navCtrl.push(NotificationsPage);
    }
    update(){
      this.navCtrl.push(UpdateProfilePage);
    }
    search(){
      this.navCtrl.push(SearchJobsPage)
    }
    jobsapplied(){
      this.navCtrl.push(JobsAppliedPage);
    }
    cateringjobs(){
      this.navCtrl.push(CateringJobsPage);
    }
}
