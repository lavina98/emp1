import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ScheduleInterviewPage } from '../schedule-interview/schedule-interview';
import { Http, Headers, RequestOptions } from '@angular/http';
import { JobDetailPage } from '../job-detail/job-detail';
import { Storage } from '@ionic/storage';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { GoogleAnalytics } from '@ionic-native/google-analytics'

@Component({
  selector: 'page-notifications',
  templateUrl: 'notifications.html'
})
export class NotificationsPage {
http:any;
notifications:any;
type1:any;
type2:any;
hash:any;
  constructor(storage: Storage,
              http: Http,
              public navCtrl: NavController, 
              public navParams: NavParams,
              private iab:InAppBrowser,
              private ga: GoogleAnalytics) {
    this.http = http;
    storage.get('user').then((id) =>{
          this.ga.trackEvent("Notifications Page", "Opened", "", id.id)
          this.ga.trackView("Notification")
        });
    storage.get('Hash').then((hash) => {
     this.hash = hash;
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': hash
    });
    let options = new RequestOptions({ headers: headers });
    storage.get('id').then((id) => {
              let body = JSON.stringify({
                user_id: id
              });

       this.http.post("http://forehotels.com:3000/api/users_notification/", body, options)
            .subscribe(data =>{
             this.notifications=JSON.parse(data._body).notification;
            },error=>{
                console.log(error);
              });
          });
        });
  }

 openPage(item){
   if(item.type == 1){
     this.navCtrl.push(JobDetailPage,{
       job: item.data
     });
   }
   if(item.type == 2){
     this.navCtrl.push(ScheduleInterviewPage,{
       sc: item.data
     })
   }
   if(item.type == 3){
     let browser = this.iab.create(item.data, '_blank', "location=no, clearsessioncache=yes, clearcache=yes, hidden=yes");
   }
 }

}
