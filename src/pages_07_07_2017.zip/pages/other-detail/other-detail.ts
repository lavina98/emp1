import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, ViewController,AlertController } from 'ionic-angular';
import { UploadResumePage } from '../upload-resume/upload-resume';
import { FormControl } from '@angular/forms';
import { Validators, FormBuilder } from '@angular/forms';
import { CityPage } from '../city/city'
import { Data } from '../../providers/data';

@Component({
  selector: 'page-other-detail',
  templateUrl: 'other-detail.html'
})
export class OtherDetailPage {
bd = {}
view:any;
pname:any;
city:any;
data:any
modal:any;
c_id:any;
todo:any;
view1:any;
we:any;
i:any;
experience:any;
length:any
name:any;
email:any
gender:any
number:any
password:any;
picture:any
otherDetailForm:any;
items:any;
item:any;
  constructor(public form: FormBuilder,public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController, public alertCtrl: AlertController) {
        this.data = navParams.get('data');
        this.we = navParams.get('we');
        this.name = navParams.get('name')
        this.email = navParams.get('email')
        this.gender = navParams.get('gender')
        this.number = navParams.get('number') 
        this.password = navParams.get('password')
        this.picture = navParams.get('picture')
        this.item = navParams.get('item')
        this.otherDetailForm = this.form.group({
      "experience":[""],
      "qualification":["", Validators.required],
      "skills":["", Validators.required],
      "org":[""],
      "catering":["Yes",Validators.required],
      "internship":["No",Validators.required],
      "referrer":["",Validators.minLength(1)]      
  })
       if(this.item == 'experienced'){
        this.view1 = true;
    }
    else{
        this.view1 = false;
    }
}
  onTypeSelected(value) {
       if(value == 'Kitchen') {
        this.view= true;
        }
        else{
            this.view= false;
        }
    }
    expectingPost(){
    if(this.pname!=null){
     this.modal = this.modalCtrl.create(ModalPage,{
         user_city: this.pname
     });
    }else{
      this.modal = this.modalCtrl.create(ModalPage)
    }
         this.modal.onDidDismiss(data => {
            this.pname = data;
        });
        this.modal.present();
  }
  preferredLocation(){
    this.navCtrl.push(CityPage)
  }
  registerForm(){
    this.items = this.otherDetailForm.value;
      this.navCtrl.push(UploadResumePage, {
                experience: this.items.experience,
                qualification:this.items.qualification,
                skills: this.items.skills,
                org:this.items.org,
                catering:this.items.catering,
                internship: this.items.internship,
                we:this.we,
                name: this.name,
                email:this.email,
                picture:this.picture,
                number:this.number,
                gender:this.gender,
                password:this.password,
                pname: this.pname,
                city: this.city,
                c_id:this.data,
                referrer: this.items.referrer
            });
        }
}
@Component({
  template: `
  <ion-header>
  <ion-navbar color="primary">
    <ion-title>
      Select Post
    </ion-title>
  </ion-navbar>
</ion-header>
 
<ion-content>
 
    <ion-searchbar [(ngModel)]="searchTerm" [formControl]="searchControl" (ionInput)="onSearchInput()"></ion-searchbar>
 
    <div *ngIf="searching" class="spinner-container">
        <ion-spinner></ion-spinner>
    </div>
 
    <ion-list>
        <ion-item *ngFor="let item of items" (click)="onclick(item)">
            {{item.designation}}
        </ion-item>
    </ion-list>
 
</ion-content>
`
})
export class ModalPage {
  searchTerm: string = '';
    searchControl: FormControl;
    items: any;
    pname:any;
    searching: any = false;
 
    constructor(public navCtrl: NavController, public dataService: Data, public viewCtrl: ViewController) {
        this.searchControl = new FormControl();
    }
 
    ionViewDidLoad() {
 
        this.setFilteredItems();
 
        this.searchControl.valueChanges.debounceTime(700).subscribe(search => {
 
            this.searching = false;
            this.setFilteredItems();
        });
 }
    onclick(item){
       this.pname = item.designation;
       this.viewCtrl.dismiss(this.pname);
       }
    onSearchInput(){
        this.searching = true;
    }
 
    setFilteredItems() {
        this.items = this.dataService.filterItems(this.searchTerm);
        }
}