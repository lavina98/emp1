import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, ViewController } from 'ionic-angular';
import { Http, RequestOptions, Headers } from '@angular/http';
import { OtherDetailPage } from '../other-detail/other-detail';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-city',
  templateUrl: 'city.html',
})
export class CityPage {
  http:any;
  items:any;
  hash:any;
  user_cities:any;
  emp_id:any;
  value:any;
  selected_cities= [];
  user_city = [];
  cities:any;
  we:any;
  length:any
  name:any;
  email:any
  gender:any
  number:any
  password:any;
  picture:any
  item:any;
  constructor(public navCtrl: NavController,private navParams:NavParams ,public alertCtrl: AlertController, public storage: Storage, http: Http, public viewCtrl: ViewController) {
    this.http = http;
        this.selected_cities = navParams.get('user_city');
        this.we = navParams.get('we');
        this.name = navParams.get('name')
        this.email = navParams.get('email')
        this.gender = navParams.get('gender')
        this.number = navParams.get('number') 
        this.password = navParams.get('password')
        this.picture = navParams.get('picture')
        this.item = navParams.get('item')
    storage.get('Hash').then((hash) => {
      this.hash = hash;
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': hash
    });
    let options = new RequestOptions({ headers: headers });
      this.http.get("http://www.forehotels.com:3000/api/city", options)
            .subscribe(data =>{
              this.items = data.json();
                for (var i = 0 ; i < this.selected_cities.length ; i++){
                for (var j = 0 ; j < this.items.length ; j++){
                  if(this.selected_cities[i] == this.items[j].c_id){
                    this.selected_cities[i] = this.items[j]
                    this.items.splice(j, 1);
                    }
                }
              }
             });
          });  
        }
        updateCity(c_id){
         let checker = 0
       for (var i = 0 ; i < this.user_city.length ; i++){
         if(this.user_city[i] == c_id){
            this.user_city.splice(i, 1);
            checker++
          }
        }
        if(checker == 0){
          this.user_city.push(c_id) 
          }
    }
        apply(){
          let data = {
            user_city:  this.user_city
          }
          this.navCtrl.push(OtherDetailPage, {
            data: data.user_city,
                item:this.item,
                we:this.we,
                name: this.name,
                email:this.email,
                number:this.number,
                gender:this.gender,
                password:this.password,
                picture:this.picture
          })
        }
      dismiss() {   
      this.navCtrl.pop();
  }
}
