import { NgZone, Component } from '@angular/core';
import { NavController, ModalController, ViewController } from 'ionic-angular';
import { Platform } from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';
import { LoadingController, AlertController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { FileChooser } from '@ionic-native/file-chooser';
import { FilePath } from '@ionic-native/file-path';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';

import { InAppBrowser } from '@ionic-native/in-app-browser';
import { ProfilePicPage } from '../profile-pic/profile-pic';
import { FormBuilder, Validators } from '@angular/forms';
import { GoogleAnalytics } from '@ionic-native/google-analytics';

@Component({
  selector: 'page-update-profile',
  templateUrl: 'update-profile.html'
})
export class UpdateProfilePage {
  items:any;
  http:any;
  location:boolean;
  empid:any;
  view:any;
  view1:any
  progress: number;
  completed:boolean;
  options:any;
  month:any;
  day:any;
  hash:any;
  cities:any;
  city_array:any;
  del_city:any;
  user_cities:any;
  social_pic:boolean;
  password:any
  constructor(private ngZone: NgZone, 
              public modalCtrl: ModalController,
              public storage: Storage,
              public platform: Platform,
              public alertCtrl: AlertController, 
              public navCtrl: NavController, 
              http: Http, 
              public loadingCtrl: LoadingController,
              private filePath: FilePath,
              private filetransfer: FileTransfer,
              private filechooser: FileChooser,
              private ga: GoogleAnalytics,
              private iab: InAppBrowser) {
    let loader = this.loadingCtrl.create({
      content: "Fetching your Account Details. Kindly wait...",
    });
    this.view = false;
    this.social_pic = false;
    loader.present();
    this.storage.get('user').then((id) =>{
          this.ga.trackEvent("Update Profile Page", "Opened", "", id.id)
          this.ga.trackView("Update Profile")
        });
    this.storage.get('Hash').then((hash) => {
      this.hash = hash;
    });
    this.storage.get('id').then((id) =>{
        this.http = http;
        var url="http://www.forehotels.com:3000/api/employee/"+id;
        this.getDetails(url, loader);
        this.empid= id;
        this.getUserCities()
      });
  }
 city(){
    this.fetchCities(this.user_cities)
  }
  getDetails(x, loader){
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': this.hash
    });
    let options = new RequestOptions({ headers: headers });
            this.http.get(x, options)
            .subscribe(data =>{
             this.items=JSON.parse(data._body).Users;
             this.password = this.items["0"].password
             if(this.password == 'f17912c58b05e01441a21cf1e9cae59c'){
              this.view1 = false
            }
            else{
              this.view1 = true
            }
             let img = this.items["0"].profile_pic.split("/")
               if(img.length > 1){
                  this.social_pic = true;
               }
             loader.dismiss(); //Bind data to items object
            },error=>{
                console.log(error);// Error getting the data
            });
   }

    getUserCities(){
      let headers = new Headers({
        'Content-Type': 'application/json',
        'Authorization': this.hash
      });
      console.log(headers)
      let options = new RequestOptions({ headers: headers });
       this.http.get("http://forehotels.com:3000/api/employee_city/"+this.empid, options)
               .subscribe(data =>{
                this.user_cities=JSON.parse(data._body).Users;
               },error=>{
                   console.log(error);
               } );
    }
    education() {
    let prompt = this.alertCtrl.create({
      title: 'Education',
      inputs: [
        {
          value: this.items["0"].qualification
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: s_data => {
            console.log(s_data);
            this.items["0"].qualification = s_data["0"];
            this.callAPI("qualification", s_data["0"])
          }
        }
      ]
    });
    prompt.present();
  }
 mobile() {
    let prompt = this.alertCtrl.create({
      title: 'Mobile Number',
      inputs: [
        {
          value: this.items["0"].contact_no
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: contact_data => {
            console.log('Saved clicked');
            this.items["0"].contact_no = contact_data["0"];
            this.callAPI("contact_no", contact_data["0"])
          }
        }
      ]
    });
    prompt.present();
  }
  fetchCities(user_cities){
       let loader = this.loadingCtrl.create({
         content: "Fetching your Account Details. Kindly wait...",
       });
       loader.present(loader)
       let headers = new Headers({
         'Content-Type': 'application/json',
         'Authorization': this.hash
       });
       let options = new RequestOptions({ headers: headers });
     this.http.get("http://forehotels.com:3000/api/city/",options)
             .subscribe(data =>{
              this.cities=JSON.parse(data._body); //Bind data to items object
              let alert = this.alertCtrl.create();
              alert.setTitle('Your Preferred Cities');
               for (var i = 0 ; i < this.cities.length ; i++){
                for (var j = 0 ; j < user_cities.length ; j++){
                  if(this.cities[i].c_id == user_cities[j].c_id){
                    alert.addInput({
                      type: 'checkbox',
                      label: this.cities[i].city_name,
                      value: this.cities[i].c_id,
                      checked:true
                    });
                    this.cities.splice(i, 1);
                  }
                }
              }
             setTimeout(() => {
               for(var city of this.cities){
                   alert.addInput({
                    type: 'checkbox',
                    label: city.city_name,
                    value: city.c_id,
                    checked: false
                   });
                 }

              alert.addButton('Cancel');
              alert.addButton({
                text: 'Okay',
                handler: data => {
                  let cities = data
                  this.updateCity(cities)
                }
              });
              alert.present();
              loader.dismiss()
            }, 2000)
             error=>{
                 console.log(error);// Error getting the data
             }
           });
   }

   updateCity(value){
     console.log(value)
    let body = JSON.stringify({
      city_id: value,
      user_id: this.empid
    });
      let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': this.hash
             });
       let options = new RequestOptions({ headers: headers });
       this.http
        .post('http://forehotels.com:3000/api/users_city', body, options)
        .map(res => res.json())
        .subscribe(
            data => {
              console.log(data);
              let alert = this.alertCtrl.create({
              title: 'Cities Updated Successfully!',
              buttons: ['OK']
            });
              alert.present();
              this.getUserCities()
            },
            err => {
            }
        );
  }
  exp() {
    let prompt = this.alertCtrl.create({
      title: 'Experience',
      inputs: [
        {
          value:this.items["0"].experience
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: exp_data => {
            console.log('Saved clicked');
            this.items["0"].experience = exp_data["0"];
            this.callAPI("experience", exp_data["0"])
          }
        }
      ]
    });
    prompt.present();
  }
  designation() {
    let prompt = this.alertCtrl.create({
      title: 'Designation',
      inputs: [
        {
          value: this.items["0"].designation
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: designation_data => {
            console.log('Saved clicked');
            this.items["0"].designation = designation_data["0"];
            this.callAPI("designation", designation_data["0"])
          }
        }
      ]
    });
    prompt.present();
  }
  org() {
    let prompt = this.alertCtrl.create({
      title: 'Current/Previous Organization',
      inputs: [
        {
          value: this.items["0"].org
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: org_data => {
            console.log('Saved clicked');
            this.items["0"].org = org_data["0"];
            this.callAPI("org", org_data["0"])
          }
        }
      ]
    });
    prompt.present();
  }
  skills() {
    let prompt = this.alertCtrl.create({
      title: 'Special Skills',
      inputs: [
        {
          value: this.items["0"].special_skills
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: ss_data => {
            console.log('Saved clicked');
            this.items["0"].special_skills = ss_data["0"];
            this.callAPI("special_skills", ss_data["0"])
          }
        }
      ]
    });
    prompt.present();
  }

  callAPI(key,value){
     let body = JSON.stringify({
          key: key,
          value: value,
          id: this.empid
          });
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': this.hash
    });
    let options = new RequestOptions({ headers: headers });

    this.http
        .put('http://www.forehotels.com:3000/api/employee', body, options)
        .map(res => res.json())
        .subscribe(
            data => {
              console.log(data);
            },
            err => {
              console.log("ERROR!: ", err);
            }
        );
    }

  resumeOptions(){
    if(this.view == true){
      this.view = false
    }
    else if(this.view == false){
      this.view = true
    }
  }

  openResume(x){
    let resume = this.items["0"].resume
    if(resume == 'created'){
    let url = "https://www.forehotels.com/registration/cv_preview/"+this.empid;
    let browser = this.iab.create(encodeURI(url), '_blank', "location=no, clearsessioncache=yes, clearcache=yes, hidden=yes");    
    }
    else{
    let url = "https://docs.google.com/gview?embedded=true&url=https://www.forehotels.com/public/emp/tmp_uploads/"+x;
    let browser = this.iab.create(encodeURI(url), '_blank', "location=no, clearsessioncache=yes, clearcache=yes, hidden=yes");

    browser.on("loadstop")
                 .subscribe(
                    () => {
                      browser.show();

                    },
                    err => {
                      console.log("InAppBrowser Loadstop Event Error: " + err);
                    });
    }  
  }

    updateProfilePic(){
      this.navCtrl.push(ProfilePicPage);
    }

    updatePassword() {
      let modal = this.modalCtrl.create(UpdatePasswordPage);
        modal.present();
    }

    updateCities(){
        let modal = this.modalCtrl.create(UpdateCitiesPage);
        modal.present();
    }
    
    uploadResume(){

    this.filechooser.open()
      .then(
        uri => {
        this.filePath.resolveNativePath(uri)
        .then(filePath => {
          this.resumeUpload(filePath);
        });
      });
  }

    resumeUpload(x){
      this.completed=false;
      var fileArray = x.split("/");
      let len = fileArray.length;
      var file = fileArray[len - 1];
      var filebits = file.split(".");
      var f = filebits[1];

      if((f != "pdf") && (f != "doc") && (f != "docx") && (f!= "rtf")){
        let alert = this.alertCtrl.create({
              title: "Invalid File Format",
              subTitle: "Allowed File extensions are PDF, DOC, DOCX and RTF only",
              buttons: ['Dismiss'],
            });
            alert.present();
      }
      else{

      //let fileTransfer = new Transfer();
     let fileTransfer: FileTransferObject = this.filetransfer.create();

      this.options = {
        fileKey: 'resume',
        fileName: x,
        mimeType: "multipart/form-data",
        headers: {
          authorization : 'e36051cb8ca82ee0Lolzippu123456*='
        },
        params: {
          name: file,
          id: this.empid
        }
      }

       let onProgress =  (progressEvent: ProgressEvent) : void => {
        this.ngZone.run(() => {
            if (progressEvent.lengthComputable) {
                let progress = Math.round((progressEvent.loaded / progressEvent.total) * 100);
                console.log(progress);
                this.progress = progress
            }
        });
    }
      this.completed = false;
      fileTransfer.onProgress(onProgress)
      fileTransfer.upload(x, encodeURI("http://forehotels.com:3000/api/upload_employee_resume"), this.options, true)
      .then((data) => {
        this.progress=null;
        this.completed=true;
        file = file.split(".")
        this.items["0"].resume = 'Forehotels_'+ file[0] + '-' + this.getDateTime() + '.' + file[1];
      }, (err) => {
        let alert = this.alertCtrl.create({
              title: err.text(),
              subTitle: err.json(),
              buttons: ['Dismiss'],
            });
            alert.present();
      });
      }
    }

    getDateTime() {
      var date = new Date();
      var year = date.getFullYear();
      this.month = date.getMonth() + 1;
      this.month = (this.month < 10 ? "0" : "") + this.month;
      this.day  = date.getDate();
      this.day = (this.day < 10 ? "0" : "") + this.day;
      return year + "-" + this.month + "-" + this.day;
    }
  }

@Component({
  template: `
  <ion-header>
  <ion-toolbar>
    <ion-title>
     Update Password
    </ion-title>
    <ion-buttons start>
      <button ion-button (click)="dismiss()">
        <ion-icon name="md-close" showWhen="android,windows,ios"></ion-icon>
      </button>
    </ion-buttons>
  </ion-toolbar>
</ion-header>
<ion-content>
<div class="cont">
<form [formGroup]="registrationForm" (ngSubmit)="loginForm()">
<ion-list>
<ion-item>
    <ion-label floating>Old Password</ion-label>
    <ion-input formControlName="old_password" type="password">
    <ion-icon name="eye" (click)="showPassword(input)"></ion-icon></ion-input>
  </ion-item>
<ion-item>
    <ion-label floating>Password</ion-label>
    <ion-input formControlName="password" type="password"></ion-input>
  </ion-item>

  <ion-item>
    <ion-label floating>Confirm Password</ion-label>
    <ion-input formControlName="password" type="password"></ion-input>
  </ion-item>
  </ion-list>
  <div padding>
  <button [disabled]="!registrationForm.valid" ion-button full>Update Password</button>
</div>
</form>
</div>
</ion-content>`
})
export class UpdatePasswordPage{
registrationForm:any;
items:any;
empid:any;
login:any;
http:any;
disable:any;
hash:any;
constructor(private alertCtrl: AlertController,public storage:Storage,public navCtrl: NavController,  private form: FormBuilder,http: Http,public viewCtrl: ViewController){
      this.registrationForm = this.form.group({
      "old_password":["",Validators.required],
      "password":["",Validators.required]
                    })
          this.storage.get('id').then((id) =>{
          this.empid = id;
        });
        this.http = http;
             }
    loginForm(){
  /*For updatepassword*/
    this.items = this.registrationForm.value;    //YOGESH!!!!!!!!!! THIS TAKES VALUE FROM FORM
    this.storage.get('Hash').then((hash) => {

    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': hash
    });
    let options = new RequestOptions({ headers: headers });
    let body = JSON.stringify({
     id: this.empid,
     old_password: this.items.old_password,
     new_password: this.items.password,
    });
    this.http
        .put('http://forehotels.com:3000/api/password', body, options)
        .subscribe(
            data => {
              let res = data.json();
              console.log(res)
              if(res.Response==false){
                let alert = this.alertCtrl.create({
                title: 'Password Doesnt Match!',
                subTitle: 'Your old password is incorrect.',
                buttons: ['RETRY']
                });
                alert.present();
              }
                else{
                let alert = this.alertCtrl.create({
                title: 'Password Updated!',
                subTitle: 'Your password has been updated successfully.',
                buttons: ['OK']
                });
                alert.present();
                this.viewCtrl.dismiss();
                }
              });
    });
    }
    dismiss() {
    this.viewCtrl.dismiss();
  }
}

@Component({
template: `
 <ion-header>
  <ion-toolbar>
    <ion-title>
     Update City
    </ion-title>
    <ion-buttons start>
      <button ion-button (click)="dismiss()">
        <ion-icon name="md-close" showWhen="android,windows,ios"></ion-icon>
      </button>
    </ion-buttons>
     <ion-buttons end>
      <button ion-button (click)="apply()">Apply</button>
    </ion-buttons>
  </ion-toolbar>
</ion-header>
<ion-content>
    <ion-item *ngFor="let cities of this.user_cities">
    <ion-label style="white-space:pre-wrap">{{cities.city_name}}</ion-label>
      <ion-checkbox (click)=updateCity(cities.c_id) checked="true"></ion-checkbox>
    </ion-item>
    <ion-list [virtualScroll]="cities">
    <ion-item *virtualItem="let item">
      <ion-label style="white-space:pre-wrap">{{item.city_name}}</ion-label>
      <ion-checkbox (click)=updateCity(item.c_id)></ion-checkbox>
    </ion-item>
    </ion-list>
</ion-content>
`
})
export class UpdateCitiesPage {
http:any;
items:any;
hash:any;
user_cities:any;
emp_id:any;
value:any;
cities:any;
update_cities= [];
 constructor(public alertCtrl: AlertController, public storage: Storage, http: Http, public viewCtrl: ViewController) {
      this.http = http;
       this.storage.get('id').then((id) =>{
            this.emp_id = id;
       });
    storage.get('Hash').then((hash) => {
      this.hash = hash;
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': hash
    });
    let options = new RequestOptions({ headers: headers });
      this.http.get("http://www.forehotels.com:3000/api/city", options)
            .subscribe(data =>{
              this.items = data.json();
              this.getUserCities()
            });
          });  
        }
      getUserCities(){
      let headers = new Headers({
        'Content-Type': 'application/json',
        'Authorization': this.hash
      });
      let options = new RequestOptions({ headers: headers });
       this.http.get("http://forehotels.com:3000/api/employee_city/"+this.emp_id, options)
               .subscribe(data =>{
                this.user_cities=JSON.parse(data._body).Users;
                this.fetchCities(this.user_cities)
               },error=>{
                   console.log(error);// Error getting the data
               } );
    }
     fetchCities(user_cities){
      let headers = new Headers({
         'Content-Type': 'application/json',
         'Authorization': this.hash
       });
       let options = new RequestOptions({ headers: headers });
       console.log("Fetch Cities called");
       this.http.get("http://forehotels.com:3000/api/city/",options)
             .subscribe(data =>{
              this.cities=JSON.parse(data._body); //Bind data to items object
               for (var i = 0 ; i < this.cities.length ; i++){
                for (var j = 0 ; j < user_cities.length ; j++){
                  if(this.cities[i].c_id == user_cities[j].c_id){
                    this.cities.splice(i, 1);
                  }
                }
              }
             error=>{
                 console.log(error);// Error getting the data
             }
           });
   }
     updateCity(c_id){
       let checker = 0
       for (var i = 0 ; i < this.update_cities.length ; i++){
         if(this.update_cities[i].c_id == c_id){
                    this.update_cities.splice(i, 1);
                    checker++
                  }
                }
        if(checker == 0){
          this.update_cities.push(c_id) 
          }
          console.log(this.update_cities)
    }
     apply(){
      let body = JSON.stringify({
      city_id: this.update_cities,
      user_id: this.emp_id
    });
      let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': this.hash
             });
       let options = new RequestOptions({ headers: headers });
       this.http
        .post('http://forehotels.com:3000/api/users_city', body, options)
        .map(res => res.json())
        .subscribe(
            data => {
              console.log(data);
              let alert = this.alertCtrl.create({
              title: 'Cities Updated Successfully!',
              buttons: ['OK']
            });
              alert.present();
            },
            err => {
            }
        );
     }
     dismiss() {   
      this.viewCtrl.dismiss();
  }
}