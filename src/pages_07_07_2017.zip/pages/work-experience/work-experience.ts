import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { CityPage } from '../city/city';

@Component({
  selector: 'page-work-experience',
  templateUrl: 'work-experience.html',
})
export class WorkExperiencePage {
  we = {}
  todo:any;
  name:any;
  email:any
  gender:any
  number:any
  password:any;
  picture:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.todo = navParams.get('todo')
    this.name = navParams.get('name')
    this.email = navParams.get('email')
    this.gender = navParams.get('gender')
    this.number = navParams.get('number') 
    this.password = navParams.get('password')
    this.picture = navParams.get('picture')
} 
 moveNext(item){
    this.navCtrl.push(CityPage, {
                item:item,
                we:this.we,
                name: this.name,
                email:this.email,
                number:this.number,
                gender:this.gender,
                password:this.password,
                picture:this.picture
            });
        }
}
