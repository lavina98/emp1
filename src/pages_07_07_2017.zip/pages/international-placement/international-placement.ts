import { Component } from '@angular/core';
import { NavController, AlertController, LoadingController } from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Storage } from '@ionic/storage';
import { GoogleAnalytics } from '@ionic-native/google-analytics';
import { PaymentOptionsPage } from '../payment-options/payment-options';
import 'rxjs/Rx';
@Component({
  selector: 'page-international-placement',
  templateUrl: 'international-placement.html'
})
export class InternationalPlacementPage {
  user:any;
  empname:any;
  checkapplied:any;
  http:any;
  hash:any;
  constructor(private loadCtrl: LoadingController,
              public navCtrl: NavController,
              http: Http, 
              private storage: Storage, 
              private alertCtrl: AlertController,
              private ga: GoogleAnalytics) {
        this.http = http;
        this.storage.get('user').then((id) =>{
          this.user = id; 
          this.ga.trackEvent("International Placement Page", "Opened", "", id.id)
          this.ga.trackView("International Placement")
        });

}
    intplacement(){
    var applied =false
    this.storage.get('Hash').then((hash) => {
      this.hash = hash;
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': hash
    });
    let options = new RequestOptions({ headers: headers });

    this.http.get("http://forehotels.com:3000/api/international_placement/"+this.user.id, options)
            .subscribe(data =>{
             this.checkapplied=JSON.parse(data._body).Users;//Bind data to items object
                for(let item of this.checkapplied ){
                  if(item.paid == 1){
                    let alert = this.alertCtrl.create({
                    title: 'Oops..!!',
                    subTitle: 'You have already applied for international placement.',
                    buttons: ['OK']
                    });
                  alert.present();
                  applied =true;
                  }
                }
                this.check(applied)
              },error=>{
                console.log(error);// Error getting the data
              });
      });

    }

    check(applied){
      if(applied == false){
              this.navCtrl.push(PaymentOptionsPage);
      }
    }
}
