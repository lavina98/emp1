import { Component } from '@angular/core';
import { NavController, LoadingController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { WorkExperiencePage } from '../work-experience/work-experience';
import { GoogleAnalytics } from '@ionic-native/google-analytics';
import { GooglePlus } from '@ionic-native/google-plus';
import { NativeStorage } from '@ionic-native/native-storage';
import { Toast } from '@ionic-native/toast';
import { Facebook } from '@ionic-native/facebook'

@Component({
  selector: 'page-register',
  templateUrl: 'register.html'
})
export class RegisterPage {
  todo = {}
  FB_APP_ID: number = 986922888110799;
  name:any;
  email:any;
  gender:any;
  registrationForm:any;
  items:any
  view:boolean=false
  picture:any
  constructor(public form: FormBuilder,
              public navParams: NavParams,
              public navCtrl: NavController,
              public storage: Storage, 
              public loadingCtrl: LoadingController,
              private ga: GoogleAnalytics,
              private toast: Toast,
              private googleplus: GooglePlus,
              private nativestorage: NativeStorage,
              private facebook: Facebook ) {
   
    this.registrationForm = this.form.group({
      "name":[this.name, Validators.required],
      "email":[this.email, Validators.required],
      "number":["", Validators.required],
      "gender":[this.gender, Validators.required],
      "password":[""]      
  })
    this.storage.get('user').then((id) =>{
          this.ga.trackEvent("Register Page", "Opened", "", id.id)
          this.ga.trackView("Register")
        });
    this.facebook.browserInit(this.FB_APP_ID, "v2.9");
}
doGoogleLogin(){
  var self = this
  let nav = this.navCtrl;
  let loading = this.loadingCtrl.create({
     spinner: 'hide',
      content: `<div class="cssload-loader">
                <div class="cssload-inner cssload-one"></div>
                <div class="cssload-inner cssload-two"></div>
                <div class="cssload-inner cssload-three"></div>
              </div><p style="color:white!important">Please Wait...</p>`,
  });
  loading.present();
  this.googleplus.login({
    'scopes': '', // optional, space-separated list of scopes, If not included or empty, defaults to `profile` and `email`.
    'webClientId': '1040945361550-od0us71pl5b6fbt722414j04hnpi77ml.apps.googleusercontent.com', // optional clientId of your Web application from Credentials settings of your project - On Android, this MUST be included to get an idToken. On iOS, it is not required.
    'offline': true
  })
  .then(function (user) {
    loading.dismiss();

    this.nativestorage.setItem('user', {
      name: user.displayName,
      email: user.email,
      picture: user.imageUrl
    })
    .then(function(){
      self.googlesingup(user.displayName,user.email)
          //this.picture = navParams.get('picture')
      // nav.push(RegisterPage, {
      //       name: user.displayName,
      //       picture: user.imageUrl,
      //       email: user.email
      //     });     
    }, function (error) {
      console.log(error);
    })
  }, function (error) {
    loading.dismiss();
    this.toast.show(error, '15000', 'bottom').subscribe(
      toast => {
        console.log(toast);
      }
    );
  });
}

 private googlesingup(googleName,googleEmail){
    this.name =  googleName
    this.email = googleEmail
    this.view = true; 
}

 private facebookSingup(facebookName,facebookEmail,facebookGender){

    this.name =  facebookName
    this.gender = facebookGender
    this.email = facebookEmail
    this.view = true;  
}

doFbLogin(){ 
  
    var self =this;
    let permissions = new Array();
    let nav = this.navCtrl;
    //the permissions your facebook app needs from the user
    permissions = ["public_profile","email"];


    this.facebook.login(permissions)
    .then(function(response){
      let userId = response.authResponse.userID;
      let params = new Array();

      //Getting name and gender properties
      this.facebook.api("/me?fields=name,gender,email", params)
      .then(function(user) {
        user.picture = "https://graph.facebook.com/" + userId + "/picture?type=large";
        //now we have the users info, let's save it in the NativeStorage
        this.nativestorage.setItem('user',
        {
          name: user.name,
          gender: user.gender,  
          picture: user.picture,
          email: user.email
        })
        .then(function(){
          self.facebookSingup(user.name,user.gender,user.email)
          // nav.push(RegisterPage, {
          //   name: user.name,
          //   gender: user.gender,
          //   picture: user.picture,
          //   email: user.email
          // });
        }, function (error) {
          console.log(error);
        })
      })
    }, function(error){
      this.toast.show(error, '15000', 'bottom').subscribe(
      toast => {
        console.log(toast);
      }
    );
    });
  }
  loginForm(){
    this.items = this.registrationForm.value;
    this.navCtrl.push(WorkExperiencePage, {
                name: this.items.name,
                email: this.items.email,
                number: this.items.number,
                gender: this.items.gender,
                password: this.items.password,
              });
            }
          }