import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, AlertController } from 'ionic-angular';
import { Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import { FileChooser } from '@ionic-native/file-chooser';
import { FilePath } from '@ionic-native/file-path';
import { FileTransfer, FileTransferObject, FileUploadOptions } from '@ionic-native/file-transfer';
import { Storage } from '@ionic/storage';
import { LoginPage } from '../login/login';
@Component({
  selector: 'page-resume-builder',
  templateUrl: 'resume-builder.html',
})
export class ResumeBuilderPage {
todo:any;
we:any;
city:any;
pname:any;
name:any;
email:any
gender:any
number:any
password:any;
picture:any
c_id:any
profile:any
qualification:any
skills:any;
org:any;
catering:any;
internship:any
experience:any
referrer: any;
resumeForm:any;
hash:any
items:any
http:any
empid:any
options:any
uploaded:any
completed:any
view_picture:any
split:any

  constructor(public alertCtrl: AlertController,
              http: Http,
              public storage: Storage,
              public loadingCtrl: LoadingController,
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public form: FormBuilder,
              private filePath: FilePath,
              private filetransfer: FileTransfer,
              private filechooser: FileChooser,) {
      this.org = navParams.get('org')
      this.http = http 
      this.resumeForm = this.form.group({
      "personal_profile":["A bright, talented and hard working individual with a bubbly, friendly personality and the ability to work as part of a team. Possessing excellent communication & hospitality skills and a proven ability to ensure that all customer expectations are met.",Validators.required],
      "address":["",Validators.required],
      "interest":["Good knowledge of food & beverage",Validators.required],
      "skills":["Communication Skills, Customer Service, Well Presented",Validators.required],
      "hobbies":["",Validators.required],
      "language":["Hindi, English",Validators.required],
      "org":[this.org, Validators.required]      
  })
      this.storage.get('Hash').then((hash) => {
        this.hash = hash;
      });
          this.name = navParams.get('name')
          this.email = navParams.get('email')
          this.number = navParams.get('number') 
          this.we = navParams.get('we')
          this.referrer = navParams.get('referrer')
          this.profile = navParams.get('experience')
          this.qualification = navParams.get('qualification')
          this.skills = navParams.get('skills')
          this.catering = navParams.get('catering')
          this.internship = navParams.get('internship') 
          if(this.profile == ''){
            this.profile = 'Fresher'
          }
          this.city = navParams.get('city')
          this.pname = navParams.get('pname')
          this.password = navParams.get('password')
          this.picture = navParams.get('picture')
          if(this.picture != null){
          this.split = this.picture.split('/')
          this.split = this.split[0]
          }
          this.gender = navParams.get('gender')
          this.c_id = navParams.get('c_id')  
          this.uploaded = 0; 
         }
         register(){
           if(this.picture == null){
      let alert = this.alertCtrl.create({
                title: 'Error!',
                subTitle: 'Kindly upload your Profile Picture to Register',
                buttons: ['OK']
                });
                alert.present();
    }
    if((this.picture != null)){
           let loading = this.loadingCtrl.create({
        spinner: 'dots',
        content: 'Creating your account...'
      });
      loading.present();
      this.items = this.resumeForm.value;
      let body = JSON.stringify({
        name: this.name,
        password: this.password,
        contact_no: this.number,
        user_type: 2,
        region: 'India',
        email: this.email,
        gender: this.gender,
        profile_pic: this.picture,
        experience: this.profile,
        designation: this.pname,
        qualification: this.qualification,
        org: this.items.org,
        internship: this.internship,
        catering: this.catering,
        referrer: this.referrer,
        personal_profile: this.items.personal_profile,
        address:this.items.address,
        interest:this.items.interest,
        skills:this.items.skills,
        hobbies:this.items.hobbies,
        language:this.items.language,
        resume:'created'
      });
       let headers = new Headers({
        'Content-Type': 'application/json',
        'Authorization': this.hash
      });
      let options = new RequestOptions({ headers: headers });
      this.http
          .post('http://forehotels.com:3000/api/insert_resume', body, options)
          .subscribe(
              datas => {
                console.log(datas);
                this.empid = JSON.parse(datas._body).User;
                loading.dismiss()
                if(this.split == 'https:'){
                  this.uploaded++
                  this.success()
              }
                else{
               this.pictureUpload(this.picture)
                }
                let city_body = JSON.stringify({
                      city_id:this.c_id,
                      user_id: this.empid
                    });
                    console.log(city_body)
        this.http
          .post('http://forehotels.com:3000/api/users_city', city_body, options)
          .map(res => res.json())
          .subscribe(
              data => {
                console.log(data);
                let email_body = JSON.stringify({
                    email: this.email,
                    mail: 'employee_welcome'
                        });
                    this.http
                    .post('http://forehotels.com:3000/api/send_email', email_body, options)
                    .map(res => res.json())
                    .subscribe(
                        data => {
                          console.log(data)
                    });
                let sms_body = JSON.stringify({
                    number: this.number,
                    text: 'Hello '+this.name+', Welcome to Forehotels. Use the Forehotels App regularly for latest Job openings'
                        });
                    this.http
                    .post('http://forehotels.com:3000/api/send_sms', sms_body, options)
                    .map(res => res.json())
                    .subscribe(
                        data => {
                          console.log(data)
                    });
              },
              err => {
                let alert = this.alertCtrl.create({
                  title: 'Oops!',
                  subTitle: err.text(),
                  buttons: ['OK']
                  });
                  alert.present();
              }
          );
              },
              err => {
                console.log("ERROR!: ", err);
              }
          );
         }
         } 
   success(){
     console.log("uploaded value: "+this.uploaded)
     if(this.uploaded == 1){
        let alert = this.alertCtrl.create({
                  title: 'Congrats!',
                  subTitle: 'Your Account Has been Created Successfully.',
                  buttons: ['OK']
                  });
                  alert.present();

        this.navCtrl.setRoot(LoginPage)
      }
   }
    uploadPicture(){
    this.filechooser.open()
      .then(
        uri => {
        this.filePath.resolveNativePath(uri)
        .then(filePath => {
          let x = filePath
          var fileArray = x.split("/");
          let len = fileArray.length;
          var file = fileArray[len - 1];
          var filebits = file.split(".");
          var f = filebits[1];

          if((f != "jpg") && (f != "png") && (f != "jpeg")){
            let alert = this.alertCtrl.create({
                  title: "Invalid File Format",
                  subTitle: "Allowed File extensions are JPG, JPEG and PNG only",
                  buttons: ['Dismiss'],
                });
                alert.present();
          }
          else{
            this.picture = x
            this.view_picture = file
          }
        });
      });
    }      
  pictureUpload(x){

      let loading = this.loadingCtrl.create({
        spinner: 'dots',
        content: 'Uploading your Picture...'
        });
      loading.present();
      var fileArray = x.split("/");
      let len = fileArray.length;
      var file = fileArray[len - 1];
      //let fileTransfer = new Transfer();     
      let fileTransfer: FileTransferObject = this.filetransfer.create();

      this.options = {
        fileKey: 'img',
        fileName: x,
        mimeType: "multipart/form-data",
        headers: {
          authorization : this.hash
        },
        params: {
          name: file,
          id: this.empid
        }
      }
      
      this.completed = false;
      fileTransfer.upload(x, encodeURI("http://forehotels.com:3000/api/upload_employee_image"), this.options, true)
      .then((data) => {
        this.uploaded++;
        this.success();
        loading.dismiss()
      }, (err) => {
        let alert = this.alertCtrl.create({
              title: err.text(),
              subTitle: err.json(),
              buttons: ['Dismiss'],
            });
            alert.present();
      });
      console.log("Uploaded "+this.uploaded)
    }       
        }