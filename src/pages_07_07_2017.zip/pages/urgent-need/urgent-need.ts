import { Component } from '@angular/core';
import { NavController, NavParams,AlertController } from 'ionic-angular';
import { DashboardPage } from '../dashboard/dashboard';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Storage } from '@ionic/storage';
@Component({
  selector: 'page-urgent-need',
  templateUrl: 'urgent-need.html'
})
export class UrgentNeedPage {
employee_id:any;
hash:any;
http:any
  constructor(public storage: Storage,http: Http,public navCtrl: NavController, public navParams: NavParams, public alertCtrl: AlertController) {
    this.http = http;
    this.storage.get('id').then((id) =>{
          this.employee_id = id; 
      });
      console.log(this.employee_id)
      this.storage.get('Hash').then((hash) => {
      this.hash = hash;
    });
}
  urgentNeed(){
    let body = JSON.stringify({
      employee_id: this.employee_id  
    });
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': this.hash
    });
    let options = new RequestOptions({ headers: headers });
      this.http
            .post('http://forehotels.com:3000/api/urgent_need', body, options)
            .map(res => res.json())
            .subscribe(data =>{
              console.log(data)
           let alert = this.alertCtrl.create({
          title: 'Successful',
          subTitle: 'We will contact you As early as Possible.',
          buttons: ['OK']
          });
          alert.present();
           setTimeout(() => {
           this.navCtrl.setRoot(DashboardPage);
          }, 2000);
            },error=>{
                console.log(error);// Error getting the data
            } );
        }
}
